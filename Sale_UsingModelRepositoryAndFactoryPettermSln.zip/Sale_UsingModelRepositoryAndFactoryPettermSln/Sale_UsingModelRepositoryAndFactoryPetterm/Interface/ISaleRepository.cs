﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Interface
{
   
     public interface ISaleRepository
    {
        IEnumerable<Sale> ShowAllSale();
        Sale GetSale(int saleNo);
        Sale CreateSale(Sale sale);
        Sale UpdateSale(Sale sale);
        Sale DeleteSale(int id);
    }
}
