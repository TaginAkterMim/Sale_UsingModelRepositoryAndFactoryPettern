﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using Sale_UsingModelRepositoryAndFactoryPetterm.Enums;
using Sale_UsingModelRepositoryAndFactoryPetterm.Factory;
using Sale_UsingModelRepositoryAndFactoryPetterm.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm
{
    internal class Program
    {
        public static SaleRepository repo = new SaleRepository();
        static void Main(string[] args)
        {
            try
            {
                DoTask();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                Console.ReadLine();
            }
        }

        private static void DoTask()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t=========== Project CSharp =========== \r");
            Console.WriteLine("\t\t\t\t                                         \r");
            Console.WriteLine();
            Console.WriteLine("\t\t\t\t          Tagin Akter Mim      \r");
            Console.WriteLine("\t\t\t\t             Id-1284898          \r");
            Console.WriteLine();
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\t\t\t\t          Sale Management\r");
            Console.WriteLine("\t\t\t\t=====================================\n");
            Console.WriteLine("\t\t\t          How Many Operation is to perform?");
            Console.WriteLine();
            int count = Convert.ToInt32(Console.ReadLine());
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (count > 0)
            {
                for (int i = 0; i < count; i++)
                {
                    Console.WriteLine("\t\t\t Select Operation \nSelect --1\nCreate --2\nUpdate --3\nDelete --4");
                    int op = Convert.ToInt32(Console.ReadLine());
                    switch (op)
                    {
                        case 1:
                            ShowAllSale(null);
                            break;
                        case 2:
                            CreateSale();
                            break;
                        case 3:
                            UpdateSale();
                            break;
                        case 4:
                            Deletesale();
                            break;
                        default:
                            ShowAllSale(null);
                            break;
                    }
                }
            }
        }

        private static void Deletesale()

        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Enter Id");
            int s = Convert.ToInt32(Console.ReadLine());
            Sale deleteSale = new Sale();
            deleteSale.SaleNo = s;
            deleteSale = repo.DeleteSale(deleteSale.SaleNo);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Delete Successfully");
            ShowAllSale(deleteSale);
        }

        private static void UpdateSale()

        {
            Console.ForegroundColor = ConsoleColor.White;
            Sale upSale = new Sale();
            Console.WriteLine("Emter Sale No");
            upSale.SaleNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name");
            upSale.CustomarName = Console.ReadLine();
            Console.WriteLine("Enter Term");
            upSale.Term = Console.ReadLine();

        EnterType:

            Console.WriteLine("Enter Payment Type: 1.Cash \n 2.Credit");
            string typeRead = Console.ReadLine();
            PaymentType paymenttype;
            try
            {
                paymenttype = (PaymentType)Enum.Parse(typeof(PaymentType), typeRead);
            }
            catch (Exception)
            {
                Console.WriteLine("Invalid Paymemnt");
                goto EnterType;
            }
            upSale.PaymentType = paymenttype;
            upSale = repo.UpdateSale(upSale);
            ShowAllSale(upSale);
        }

        private static void CreateSale()

        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Sale sale = new Sale();
            Console.WriteLine("Enter Name");
            sale.CustomarName = Console.ReadLine();

            Console.WriteLine("Enter Address");
            sale.ShippingAddress = Console.ReadLine();

        EnterType:

            Console.WriteLine("Enter Catagory: 1.Cash , 2.Credit");
            string typeRead = Console.ReadLine();

            PaymentType houseCatagory;
            try
            {
                houseCatagory = (PaymentType)Enum.Parse(typeof(PaymentType),
                    typeRead);
            }
            catch (Exception)
            {
                Console.WriteLine("Invalid Paymemnt");
                goto EnterType;
            }

            sale.PaymentType = houseCatagory;
            BaseSaleFactory houseFactory = new SaleManagerFactory()
                .CreateFactory(sale);
            houseFactory.TotalSale();
            repo.CreateSale(sale);
            ShowAllSale(sale);
        }

        private static void ShowAllSale(object value)
        {
            Console.WriteLine("==================================================================================================================");
            IEnumerable<Sale> sale = repo.ShowAllSale();
            Console.WriteLine
            (string.Format
              ("|{0,5} |{1,17} | {2,-17} |{3,20} |     {4,15}        |{5,13} |"
                , "SaleNo", "CustomarName ", "PaymentType", "DelivarySystem", "SaleDate", "SaleAmount", "PaymentDate"
              )
            );
            Console.WriteLine("==================================================================================================================");

            Console.WriteLine();

            foreach (Sale item in sale)
            {
                Console.WriteLine
                (string.Format
                  ("|{0,5} | {1,17} | {2,-17} |{3,20} | {4,25}  |{5,13} |",
                  item.SaleNo, item.CustomarName, item.PaymentType, item.DelivarySystem, item.SaleDate, item.SaleAmount
                  )
                );
                Console.WriteLine("__________________________________________________________________________________________________________________");
            }

        }
    }
}
