﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Enums
{
   public enum PaymentType
   {
        CreditPaytment = 1, CashPaytment
   }

    public enum DelivarySystem
    {
        InPreson = 1, ThroughCurier
    }
}
