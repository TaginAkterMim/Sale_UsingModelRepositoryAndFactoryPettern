﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using Sale_UsingModelRepositoryAndFactoryPetterm.Enums;
using Sale_UsingModelRepositoryAndFactoryPetterm.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Repository
{
    
    public class SaleRepository : ISaleRepository
    {
        private List<Sale> saleList;
        public SaleRepository()
        {
            saleList = new List<Sale>()
            {
                new Sale()
                {
                    SaleNo=1,
                    CustomarName="Tagin",
                    PaymentType=PaymentType.CreditPaytment,
                    DelivarySystem=DelivarySystem.ThroughCurier,
                    SaleDate= DateTime.Now,
                    SaleAmount=100000
                },
                new Sale()
                {
                    SaleNo=2,
                    CustomarName="Mim",
                    PaymentType=PaymentType.CreditPaytment,
                    DelivarySystem=DelivarySystem.InPreson,
                    SaleDate= DateTime.Now,
                    SaleAmount=120000
                },
                new Sale()
                {
                    SaleNo=3,
                    CustomarName="Moni",
                    PaymentType=PaymentType.CashPaytment,
                    DelivarySystem=DelivarySystem.InPreson,
                    SaleDate= DateTime.Now,
                    SaleAmount=300000
                },
                new Sale()
                {
                    SaleNo=4,
                    CustomarName="Nusrat",
                    PaymentType=PaymentType.CashPaytment,
                    DelivarySystem=DelivarySystem.ThroughCurier,
                    SaleDate= DateTime.Now,
                    SaleAmount=650000
                },
                new Sale()
                {
                    SaleNo=5,
                    CustomarName="Jannat",
                    PaymentType=PaymentType.CreditPaytment,
                    DelivarySystem=DelivarySystem.InPreson,
                    SaleDate= DateTime.Now,
                    SaleAmount=80000
                },
                new Sale()
                {
                    SaleNo=6,
                    CustomarName="Suktara",
                    PaymentType=PaymentType.CashPaytment,
                    DelivarySystem=DelivarySystem.ThroughCurier,
                    SaleDate= DateTime.Now,
                    SaleAmount=190000
                }
            };
        }

        public Sale CreateSale(Sale sale)
        {
            Sale existingSale = ((from s in saleList
                                  orderby s.SaleNo descending
                                  select s).Take(1)).Single() as Sale;
            sale.SaleNo = existingSale.SaleNo + 1;
            saleList.Add(sale);
            return sale;
        }

        public Sale DeleteSale(int saleNo)
        {
            Sale deleteSale = GetSale(saleNo);
            if (deleteSale != null)
            {
                saleList.Remove(deleteSale);
            }
            return deleteSale;
        }

        public Sale GetSale(int SaleNo)
        {
            var sale = (from s in saleList where s.SaleNo == SaleNo select s)
                .SingleOrDefault();
            return sale;
        }

        public IEnumerable<Sale> ShowAllSale()
        {
            return from rows in saleList select rows;
        }

        public Sale UpdateSale(Sale upSale)
        {
            Sale sale = GetSale(upSale.SaleNo);
            if (sale != null)
            {
                sale.SaleNo = upSale.SaleNo;
                sale.CustomarName = upSale.CustomarName;
                sale.PaymentType = upSale.PaymentType;
                sale.DelivarySystem = upSale.DelivarySystem;
                sale.SaleDate = upSale.SaleDate;
                sale.SaleAmount = upSale.SaleAmount;
                sale.PaymentDate = upSale.PaymentDate;
                sale.Term = upSale.Term;
                sale.ShippingAddress = upSale.ShippingAddress;
                sale.Discount = upSale.Discount;
                sale.DelivaryCost = upSale.DelivaryCost;
            }
            return sale;
        }
    }
}
