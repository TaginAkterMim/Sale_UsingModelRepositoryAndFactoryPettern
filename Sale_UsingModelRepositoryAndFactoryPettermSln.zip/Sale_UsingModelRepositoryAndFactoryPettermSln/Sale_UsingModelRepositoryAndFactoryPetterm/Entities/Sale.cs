﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Entities
{
     public class Sale
    {
        int saleNo;
        string customerName;
        PaymentType paymentType;
        DelivarySystem delivarySystem;
        DateTime saleDate;
        int saleAmount;

        public Sale()
        {

        }

        public Sale(int saleNo, string customerName, PaymentType paymentType,
            DelivarySystem delivarySystem, DateTime saleDate, int saleAmount)
        {
            this.saleNo = saleNo;
            this.customerName = customerName;
            this.paymentType = paymentType;
            this.delivarySystem = delivarySystem;
            this.saleDate = saleDate;
            this.SaleAmount = saleAmount;
        }

        public DateTime PaymentDate { get; set; }
        public string Term { get; set; }
        public string ShippingAddress { get; set; }
        public int Discount { get; set; }
        public int DelivaryCost { get; set; }
        public int SaleNo { get => saleNo; set => saleNo = value; }
        public string CustomarName { get => customerName; set => customerName = value; }
        public PaymentType PaymentType { get => paymentType; set => paymentType = value; }
        public DelivarySystem DelivarySystem { get => delivarySystem; set => delivarySystem = value; }
        public DateTime SaleDate { get => saleDate; set => saleDate = value; }
        public int SaleAmount { get => saleAmount; set => saleAmount = value; }
    }
}
