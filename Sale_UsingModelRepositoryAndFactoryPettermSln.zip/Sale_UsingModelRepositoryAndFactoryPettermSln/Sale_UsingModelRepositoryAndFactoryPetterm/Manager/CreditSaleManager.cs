﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Manager
{
   
    public class CreditSaleManager : ISaleManager
    {
        public decimal GetPay()
        {
            double texPcnt = .50;
            double basic = 20000;
            double pay = basic * texPcnt;
            return (decimal)pay;
        }

        public decimal GetUtility()
        {
            double waterBill = 5000;
            double EBill = 350;
            double UBill = waterBill + EBill;
            return (decimal)EBill;
        }

        public decimal GarageCost()
        {
            return 60000;
        }

        public int GetDelivary()
        {
            return 0;
        }

        public int GetDiscount()
        {
            return 100;
        }
    }
}
