﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using Sale_UsingModelRepositoryAndFactoryPetterm.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Factory
{
    public abstract class BaseSaleFactory
    {
        protected Sale _sale;

        protected BaseSaleFactory(Sale sale)
        {
            _sale = sale;
        }
        public abstract ISaleManager Create();

        public Sale TotalSale()
        {
            ISaleManager manager = this.Create();
            _sale.Discount = manager.GetDiscount();
            _sale.DelivaryCost = manager.GetDelivary();
            return _sale;
        }
    }
}
