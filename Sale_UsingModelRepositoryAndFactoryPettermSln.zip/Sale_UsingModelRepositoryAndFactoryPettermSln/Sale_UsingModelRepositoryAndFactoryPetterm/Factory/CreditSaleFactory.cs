﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using Sale_UsingModelRepositoryAndFactoryPetterm.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Factory
{

    public class CreditSaleFactory : BaseSaleFactory
    {

        public CreditSaleFactory(Sale sale) : base(sale)
        {

        }
        public override ISaleManager Create()
        {
            CreditSaleManager manager = new CreditSaleManager();
            return manager;
        }
    }
}
