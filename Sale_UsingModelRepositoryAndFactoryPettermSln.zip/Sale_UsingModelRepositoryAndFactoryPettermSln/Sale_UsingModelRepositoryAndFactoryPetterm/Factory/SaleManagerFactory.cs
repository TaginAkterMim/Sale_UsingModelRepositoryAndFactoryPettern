﻿using Sale_UsingModelRepositoryAndFactoryPetterm.Entities;
using Sale_UsingModelRepositoryAndFactoryPetterm.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sale_UsingModelRepositoryAndFactoryPetterm.Factory
{
    
    public class SaleManagerFactory
    {
        public BaseSaleFactory CreateFactory(Sale sale)
        {
            BaseSaleFactory factory = null;

            if (sale.PaymentType == PaymentType.CreditPaytment)
            {
                factory = new CreditSaleFactory(sale);
            }
            else if (sale.PaymentType == PaymentType.CashPaytment)
            {
                factory = new CashSaleFactory(sale);
            }
            return factory;
        }
    }
}
